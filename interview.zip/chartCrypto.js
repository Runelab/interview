// alphavantage apiKey J06QACM0IZY7CCHY 
// https://www.alphavantage.co/documentation (closing daily US con USD market)
const moment = require("moment") //https://momentjs.com/docs/
const exampleData = require("./exampleDataCrypto.json")
module.exports.default = function (req, res, next) {
    var rp = require('request-promise'); //https://www.npmjs.com/package/request-promise
    const formattedData = {}
    Promise.all([
        rp({
            uri: 'https://www.alphavantage.co/query?function=DIGITAL_CURRENCY_DAILY&symbol=BTC&market=USD&apikey=J06QACM0IZY7CCHY',
            json: true // Automatically parses the JSON string in the response
        }).then((result) => {
            formattedData["BTC"] = Object.keys(result["Time Series (Digital Currency Daily)"]).map((key, index) => {
                return [moment(key, "YYYY-MM-DD").unix() * 1000, Number(result["Time Series (Digital Currency Daily)"][key]['4a. close (USD)'])]
            }).reverse()
        }),
        rp({
            uri: 'https://www.alphavantage.co/query?function=DIGITAL_CURRENCY_DAILY&symbol=LTC&market=USD&apikey=J06QACM0IZY7CCHY',
            json: true // Automatically parses the JSON string in the response
        }).then((result) => {
            formattedData["LTC"] = Object.keys(result["Time Series (Digital Currency Daily)"]).map((key, index) => {
                return [moment(key, "YYYY-MM-DD").unix() * 1000, Number(result["Time Series (Digital Currency Daily)"][key]['4a. close (USD)'])]
            }).reverse()
        }),
        rp({
            uri: 'https://www.alphavantage.co/query?function=DIGITAL_CURRENCY_DAILY&symbol=ETH&market=USD&apikey=J06QACM0IZY7CCHY',
            json: true // Automatically parses the JSON string in the response
        }).then((result) => {
            formattedData["ETH"] = Object.keys(result["Time Series (Digital Currency Daily)"]).map((key, index) => {
                return [moment(key, "YYYY-MM-DD").unix() * 1000, Number(result["Time Series (Digital Currency Daily)"][key]['4a. close (USD)'])]
            }).reverse()

        })]).then(() => {
            res.send(formattedData);
        })
}

